const PUBLIC_REST_API_ENDPOINT = String("http://103.35.121.219:1337");
//const PUBLIC_REST_API_ENDPOINT = String("https://api.pareekshn.com");
const BEARER_TOKEN = String(
	"qDJhbGciOiJIUzI1NiJ9.e30.ZRrHA1JJJW8opsbCGfG_HACGpVUMN_a9IV7pAx_Zdrt56FrtNv"
);

const BLANK_MSG = String("Please fill the all filelds.");
const TRY_AGAIN_MSG = String("Please try again...");


export { PUBLIC_REST_API_ENDPOINT, BEARER_TOKEN, BLANK_MSG, TRY_AGAIN_MSG };
