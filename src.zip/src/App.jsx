import { Outlet } from "react-router";
import LoginScreen from "./pages/LoginScreens/LoginScreen";

function App() {
	return (
		<>
			<LoginScreen />
			{/* <Outlet /> */}
		</>
	);
}

export default App;
